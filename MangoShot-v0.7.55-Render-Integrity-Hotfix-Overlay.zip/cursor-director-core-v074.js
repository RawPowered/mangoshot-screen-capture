/* Non-destructive cursor effects, source-time mapping and reviewed camera proposals. */
(function(root){'use strict';
const c=root.MangoCursorCoreV073||(typeof require==='function'?require('./cursor-effects-v073.js'):null);
const SCHEMA='mangoshot.cursor.director.v1',RECIPE='mangoshot.cursor.director.recipe.v1',PRESET='mangoshot.cursor.director.preset.v1';
const num=(v,a,b,k)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<a||v>b)throw Error('Invalid '+k);return v;};
const obj=(v,keys)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).some(k=>!keys.includes(k)))throw Error('Unexpected director field');return v;};
const defaults={spotlight:true,ring:false,pulse:false,marker:'none',radius:9,dim:.55,feather:.35,color:'#d0ff87',smooth:180,markerSize:1};
const live=id=>typeof id==='string'&&id.startsWith('live-capture-');
const presets={spotlight:{},highlight:{spotlight:false,ring:true},tutorial:{ring:true,pulse:true,marker:'dot'},presentation:{spotlight:false,ring:true,pulse:true,marker:'arrow',color:'#ffe38a'},minimal:{spotlight:false,marker:'dot',markerSize:.8}};
function style(raw={}){obj(raw,Object.keys(defaults));const s={...defaults,...raw};
for(const k of ['spotlight','ring','pulse'])if(typeof s[k]!=='boolean')throw Error('Invalid '+k);
if(!['none','dot','arrow'].includes(s.marker)||!/^#[a-f0-9]{6}$/i.test(s.color)||typeof s.color!=='string')throw Error('Invalid marker/color');
num(s.radius,3,25,'radius');num(s.dim,0,.85,'dim');num(s.feather,0,.9,'feather');num(s.smooth,0,600,'smoothing');num(s.markerSize,.5,3,'marker size');return s;}
function preset(k){if(!Object.prototype.hasOwnProperty.call(presets,k))throw Error('Unknown preset');return style(presets[k]);}
function presetFile(p){obj(p,['schema','name','style']);if(p.schema!==PRESET||typeof p.name!=='string'||!p.name.trim()||p.name.trim().length>48||/[\u0000-\u001f]/.test(p.name))throw Error('Invalid preset');return {schema:PRESET,name:p.name.trim(),style:style(p.style)};}
function regions(list,d=86400){if(!Array.isArray(list)||list.length>240||list.filter(r=>live(r?.id)).length>120||list.filter(r=>!live(r?.id)).length>120)throw Error('Maximum 120 cursor regions per live/post track');const a=list.map(r=>{
obj(r,['id','start','end','enabled','style']);if(typeof r.id!=='string'||!/^[\w-]{1,90}$/.test(r.id)||typeof r.enabled!=='boolean')throw Error('Invalid effect region');
num(r.start,0,d,'source in');num(r.end,0,d,'source out');if(r.end-r.start<.03999)throw Error('Effect region too short');return {...r,style:style(r.style)};
}).sort((a,b)=>a.start-b.start);
if(new Set(a.map(r=>r.id)).size!==a.length)throw Error('Duplicate effect ID');for(const group of [a.filter(r=>live(r.id)),a.filter(r=>!live(r.id))])for(let i=1;i<group.length;i++)if(group[i].start<group[i-1].end-.00001)throw Error('Overlapping cursor regions on the same track');return a;}
function check(raw,d=86400){obj(raw,['schema','regions','trace']);if(raw.schema!==SCHEMA)throw Error('Invalid director schema');const trace=raw.trace==null?null:c.trace(raw.trace),list=regions(raw.regions,d);
if(list.length&&!trace)throw Error('Cursor path required');if(trace&&(trace.samples.some(s=>s[0]>d+.5)||trace.clicks?.some(s=>s[0]>d+.5)||trace.capture&&['sourceSamples','sourceClicks','cameraFrames','states'].some(k=>trace.capture[k].some(s=>s[0]>d+.5))))throw Error('Trace exceeds source duration');
return {schema:SCHEMA,regions:list,trace};}
function sections(parts){let t=0;return parts.map(p=>{const r={a:p.start,b:p.end,in:t,out:t+p.end-p.start};t=r.out;return r;});}
function sourceAt(parts,t){const s=sections(parts);if(!Number.isFinite(t)||t<0||!s.length||t>s.at(-1).out+.00001)return null;const r=s.find(r=>t<r.out-.00001)||s.at(-1);return {source:Math.min(r.b,Math.max(r.a,r.a+t-r.in)),floor:r.a};}
function project(parts,list){return sections(parts).flatMap(p=>list.flatMap(r=>{const a=Math.max(r.start,p.a),b=Math.min(r.end,p.b);return b-a>.00001?[{id:r.id,start:p.in+a-p.a,end:p.in+b-p.a,enabled:r.enabled}]:[];}));}
function addRange(list,parts,start,end,s,id,d){const p=sections(parts),len=p.at(-1)?.out||0;num(start,0,len,'sequence in');num(end,0,len,'sequence out');if(end-start<.04)throw Error('Select a longer range');
const intervals=p.flatMap(r=>{const a=Math.max(r.in,start),b=Math.min(r.out,end);return b-a>=.03999?[{start:r.a+a-r.in,end:Math.min(d,r.a+b-r.in)}]:[];}).sort((a,b)=>a.start-b.start);
const merged=[];for(const r of intervals){const m=merged.at(-1);if(m&&r.start<=m.end+.00001)m.end=Math.max(m.end,r.end);else merged.push(r);}if(!merged.length)throw Error('No retained footage');
return regions([...list,...merged.map((r,i)=>({...r,id:id+'-'+i,enabled:true,style:style(s)}))],d);}
function smoothPoint(t,time,ms,floor){const p=c.sampleAt(t,time);if(!p||!ms)return p;let x=p.x*2,y=p.y*2,w=2;for(let i=1;i<=4;i++){const at=time-ms*i/4000;if(at<floor)break;const q=c.sampleAt(t,at);if(!q)break;const k=(5-i)/5;x+=q.x*k;y+=q.y*k;w+=k;}return {x:x/w,y:y/w};}
function transform(p,z){return p?c.point({x:z.x+(p.x-z.x)*z.scale,y:z.y+(p.y-z.y)*z.scale}):null;}
function clickAt(trace,t,floor){const a=trace.clicks||[];let lo=0,hi=a.length;while(lo<hi){const m=(lo+hi)>>1;if(a[m][0]<=t)lo=m+1;else hi=m;}const p=a[lo-1];return p&&p[0]>=floor&&t-p[0]<.45?{x:p[1],y:p[2],age:(t-p[0])*1000}:null;}
function paint(ctx,trace,list,parts,t,z,w,h){if(!trace||!list.length)return false;const m=sourceAt(parts,t);if(!m)return false;const active=list.filter(x=>x.enabled&&m.source>=x.start&&m.source<x.end).sort((a,b)=>Number(live(b.id))-Number(live(a.id)));let painted=false;for(const r of active)painted=paintRegion(ctx,trace,r,m,z,w,h)||painted;return painted;}
function paintRegion(ctx,trace,r,m,z,w,h){const s=r.style,floor=Math.max(m.floor,r.start),p=transform(smoothPoint(trace,m.source,s.smooth,floor),z);
if(p){c.draw(ctx,p,c.config({spotlight:s.spotlight,ring:s.ring,radius:s.radius,dim:s.dim,feather:s.feather,color:s.color}),w,h);if(s.marker!=='none'){const x=p.x*w,y=p.y*h,k=Math.max(3,Math.min(w,h)*.009*s.markerSize);ctx.save();ctx.fillStyle=s.color;ctx.strokeStyle='#121814';ctx.lineWidth=Math.max(1,k*.2);ctx.beginPath();if(s.marker==='dot')ctx.arc(x,y,k,0,Math.PI*2);else{ctx.moveTo(x,y);ctx.lineTo(x+k*.25,y+k*2.8);ctx.lineTo(x+k*.9,y+k*1.7);ctx.lineTo(x+k*1.5,y+k*2.5);ctx.lineTo(x+k*1.9,y+k*2.1);ctx.lineTo(x+k*1.2,y+k*1.4);ctx.lineTo(x+k*2.4,y+k*1.2);ctx.closePath();}ctx.fill();ctx.stroke();ctx.restore();}}
const click=s.pulse?clickAt(trace,m.source,floor):null,q=click&&transform(click,z);if(q){const k=Math.min(w,h)*s.radius/100;ctx.save();ctx.strokeStyle=s.color;ctx.lineWidth=Math.max(2,Math.min(w,h)*.003);ctx.globalAlpha=1-click.age/450;ctx.beginPath();ctx.arc(q.x*w,q.y*h,k*(.25+.65*click.age/450),0,Math.PI*2);ctx.stroke();ctx.restore();}return !!(q||p&&(s.spotlight&&s.dim>0||s.ring||s.marker!=='none'));}
function smart(raw={}){obj(raw,['scale','transition','hold','limit','mode']);const s={scale:1.75,transition:.4,hold:1.2,limit:12,mode:'auto',...raw};num(s.scale,1.1,4,'scale');num(s.transition,.1,2,'transition');num(s.hold,.3,8,'hold');num(s.limit,1,40,'limit');if(!Number.isInteger(s.limit)||!['auto','clicks','dwell'].includes(s.mode))throw Error('Invalid smart settings');return s;}
function suggest(trace,parts,existing,raw={}){const s=smart(raw);if(!trace?.samples?.length)return [];const points=[],clicks=trace.clicks||[];
if(s.mode==='clicks'||s.mode==='auto'&&clicks.length)for(const [time,x,y] of clicks)points.push({time,x,y,reason:'Recorded click'});
else{let first=null,last=null;for(const [time,x,y] of trace.samples){if(x===null){first=null;last=null;continue;}if(!first||last===null||time-last>.55||Math.hypot(x-first.x,y-first.y)>.035)first={time,x,y};if(time-first.time>=.6&&!first.used){points.push({time,x,y,reason:'Dwell candidate (not a click)'});first.used=true;}last=time;}}
const out=[],span=2*s.transition+s.hold,keys=[...existing].sort((a,b)=>a.start-b.start);
for(const p of sections(parts))for(const q of points){if(q.time<p.a||q.time>=p.b)continue;const at=p.in+q.time-p.a,end=at+span;if(end>p.out-.01||out.some(x=>at<x.end+.25&&end>x.start-.25))continue;const prev=keys.filter(k=>k.start<=at).at(-1);if(prev&&(prev.scale!==1||prev.start+prev.duration>at)||keys.some(k=>k.start>=at-.00001&&k.start<end+.00001))continue;out.push({id:'proposal-'+(out.length+1),start:at,end,x:q.x,y:q.y,reason:q.reason,scale:s.scale,transition:s.transition,hold:s.hold});if(out.length>=s.limit)return out;}return out;}
function recipe(r){if(!r||r.schema!==RECIPE)throw Error('Invalid director recipe schema');const a=r.action;
if(a==='effects.add'){obj(r,['schema','action','start','end','style']);return {action:a,start:num(r.start,0,86400,'in'),end:num(r.end,0,86400,'out'),style:style(r.style)};}
if(a==='effects.update'||a==='effects.remove'){obj(r,a==='effects.update'?['schema','action','id','start','end','style','enabled']:['schema','action','id']);if(typeof r.id!=='string'||!/^[\w-]{1,90}$/.test(r.id))throw Error('Invalid region ID');const o={action:a,id:r.id};if(r.style!=null)o.style=style(r.style);if(r.start!=null)o.start=num(r.start,0,86400,'source in');if(r.end!=null)o.end=num(r.end,0,86400,'source out');if(r.enabled!=null){if(typeof r.enabled!=='boolean')throw Error('Invalid enabled');o.enabled=r.enabled;}return o;}
if(a==='smartZoom.propose'){obj(r,['schema','action','settings']);return {action:a,settings:smart(r.settings)};}
if(a==='smartZoom.apply'){obj(r,['schema','action','proposalId','selected']);if(typeof r.proposalId!=='string'||r.proposalId.length>90||!Array.isArray(r.selected)||!r.selected.length||r.selected.length>40||new Set(r.selected).size!==r.selected.length||r.selected.some(x=>typeof x!=='string'||!/^proposal-\d+$/.test(x)))throw Error('Invalid proposal selection');return {action:a,proposalId:r.proposalId,selected:[...r.selected]};}
throw Error('Unknown director action');}
const api=Object.freeze({SCHEMA,RECIPE,PRESET,preset,presetFile,style,regions,check,project,addRange,sourceAt,smoothPoint,transform,clickAt,paint,smart,suggest,recipe});root.MangoCursorDirectorCoreV074=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
